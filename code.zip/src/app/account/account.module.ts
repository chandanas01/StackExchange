import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatMenuModule } from '@angular/material/menu';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import {
  MatInputModule, MatPaginatorModule, MatProgressSpinnerModule, MatSortModule, MatTableModule, MatNativeDateModule,
  MatIconModule, MatButtonModule, MatCardModule, MatFormFieldModule, MatSidenavModule, MatListModule, MatToolbarModule, MatSelectModule,
  MatCheckboxModule
} from '@angular/material';

import { MatExpansionModule } from '@angular/material/expansion';
import { AccountRoutingModule } from './account-routing.module';
import { AccountsComponent } from './account.component';



@NgModule({
  declarations: [AccountsComponent],
  imports: [
    CommonModule,
    AccountRoutingModule,
    FormsModule, ReactiveFormsModule,
    MatInputModule, MatPaginatorModule, MatProgressSpinnerModule, MatSortModule, MatTableModule, MatNativeDateModule,
    MatIconModule, MatButtonModule, MatCardModule, MatFormFieldModule, MatSidenavModule, MatListModule, MatToolbarModule,
    MatExpansionModule, MatCheckboxModule, MatSelectModule 
  ],
  exports: [
    MatSortModule,
    MatFormFieldModule,
    MatPaginatorModule,
    MatInputModule,
    MatSidenavModule,
    MatToolbarModule,
    MatMenuModule,
    MatExpansionModule
    //MatSort, MatTableDataSource, MatPaginator 
  ],
})
export class AccountModule { }



