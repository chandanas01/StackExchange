import { Component, OnInit } from '@angular/core';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-layout',
  templateUrl: './layout.component.html',
  styleUrls: ['./layout.component.css']
})
export class LayoutComponent implements OnInit {
  sidenavWidth = 10;
  constructor() { }

  ngOnInit() {
  }

  increase() {
    this.sidenavWidth = 10;
    console.log("increase sidenav width");
  }
  decrease() {
    this.sidenavWidth = 4;
    console.log("decrease sidenav width");
  }
}
