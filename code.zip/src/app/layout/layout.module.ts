import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FlexLayoutModule } from '@angular/flex-layout';
import { MatIconModule, MatToolbarModule, MatSidenavModule, MatListModule } from '@angular/material';
import { MatMenuModule } from '@angular/material/menu';
import { RouterModule } from '@angular/router';
import { LayoutComponent } from './layout.component'
import { LayoutRoutingModule } from './layout-routing.module';

@NgModule({

  declarations: [LayoutComponent],
  imports: [
    CommonModule,
    LayoutRoutingModule,
    FlexLayoutModule,
    MatIconModule,
    MatMenuModule, MatToolbarModule,
    MatSidenavModule, MatListModule,
    RouterModule
  ]
})
export class LayoutModule { }
